# AnimalBook

## Replaces Facebook profile pictures with friendly animals